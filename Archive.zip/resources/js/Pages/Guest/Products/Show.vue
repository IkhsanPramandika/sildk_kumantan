<template>
    <div>
        <h1>Product Details</h1>
        <div class="product-details">
            <LazyImage 
                :src="product.image_url" 
                alt="Product Image"
                imageClass="max-w-[300px] h-auto object-contain"
            />
            <div class="product-info">
                <h2>{{ product.name }}</h2>
                <p>{{ product.description }}</p>
                <p>Price: Rp {{ product.price }}</p>
                <p>Category: {{ product.category }}</p>
            </div>
        </div>
        <Link :href="route('products.index')">Back to Products</Link>
    </div>
</template>

<script setup>
import { defineProps } from 'vue';
import { Link } from '@inertiajs/vue3';
import LazyImage from '@/Components/LazyImage.vue';

const props = defineProps({
    product: {
        type: Object,
        required: true
    }
});
</script>

<style scoped>
.product-details {
    display: flex;
    gap: 2rem;
    margin: 2rem 0;
}

.product-info {
    flex: 1;
}
</style>
