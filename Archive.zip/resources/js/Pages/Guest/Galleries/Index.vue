<template>
    <div>
        <h1>Galleries</h1>
        <p>This is the galleries index page.</p>
    </div>
</template>
