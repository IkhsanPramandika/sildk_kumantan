<template>
    <div>
        <div>
            <!-- Session Status -->
            <div class="mb-4" v-if="$page.props.sessionStatus">
                <div class="font-medium text-sm text-green-600">
                    {{ $page.props.sessionStatus }}
                </div>
            </div>

            <!-- Validation Errors -->
            <div v-if="$page.props.errors">
                <div class="font-medium text-red-600">
                    Whoops! Something went wrong.
                </div>

                <ul class="mt-3 list-disc list-inside text-sm text-red-600">
                    <li v-for="(error, key) in $page.props.errors" :key="key">
                        {{ error }}
                    </li>
                </ul>
            </div>
        </div>

        <slot />
    </div>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
    components: {
    },
});
</script>
