<template>
    <div>
        <h1>Event Details</h1>
        <div v-if="event">
            <h2>{{ event.name }}</h2>
            <p>Description: {{ event.description }}</p>
            <p>Date: {{ event.start_time }}</p>
            <p>Location: {{ event.location }}</p>
            <button @click="goBack">Back to Events</button>
        </div>
        <div v-else>
            <p>Loading event details...</p>
        </div>
    </div>
</template>

<script>
import { ref, onMounted } from 'vue';

export default {
    props: {
        id: {
            type: String,
            required: true
        }
    },
    setup(props) {
        const event = ref(null);

        onMounted(async () => {
            try {
                const response = await axios.get(route('api.events.show', { event: props.id }));
                event.value = response.data.data;
            } catch (error) {
                console.error('Error fetching event:', error);
            }
        });

        const goBack = () => {
            window.location.href = route('events.index');
        };

        return {
            event,
            goBack
        };
    }
}
</script>
