<?php

namespace App\Http\Controllers\Guest;

use App\Http\Controllers\Controller;
use App\Models\Event;
use Inertia\Inertia;

class EventController extends Controller
{
    public function index()
    {
        $events = Event::with('images')
            ->where('start_date', '>=', now())
            ->orderBy('start_date')
            ->paginate(9)
            ->through(function ($event) {
                return [
                    'id' => $event->id,
                    'title' => $event->title,
                    'description' => $event->description,
                    'category' => $event->category,
                    'image_url' => $event->featured_image,
                    'start_date' => $event->start_date,
                    'end_date' => $event->end_date,
                    'location' => $event->location,
                ];
            });

        return Inertia::render('Guest/Events/Index', [
            'events' => $events,
        ]);
    }

    public function show(Event $event)
    {
        $event->load('images');

        $relatedEvents = Event::with('images')
            ->where('status', 'published')
            ->where('id', '!=', $event->id)
            ->where('category', $event->category)
            ->where('start_date', '>=', now())
            ->orderBy('start_date')
            ->take(2)
            ->get()
            ->map(function ($event) {
                return [
                    'id' => $event->id,
                    'title' => $event->title,
                    'description' => $event->description,
                    'category' => $event->category,
                    'image_url' => $event->featured_image,
                    'start_date' => $event->start_date,
                    'end_date' => $event->end_date,
                    'location' => $event->location,
                ];
            });

        return Inertia::render('Guest/Events/Show', [
            'event' => [
                'id' => $event->id,
                'title' => $event->title,
                'description' => $event->description,
                'category' => $event->category,
                'image_url' => $event->featured_image,
                'start_date' => $event->start_date,
                'end_date' => $event->end_date,
                'location' => $event->location,
            ],
            'relatedEvents' => $relatedEvents,
        ]);
    }
}
