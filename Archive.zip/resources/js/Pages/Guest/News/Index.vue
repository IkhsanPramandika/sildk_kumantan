<template>
    <GuestLayout title="Berita">
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h1 class="text-2xl font-semibold text-gray-900 mb-6">Berita Terbaru</h1>
                        
                        <!-- Filters -->
                        <div class="mb-6 flex flex-wrap gap-4">
                            <select v-model="filters.category" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                <option value="">Semua Kategori</option>
                                <option value="umum">Umum</option>
                                <option value="pemerintahan">Pemerintahan</option>
                                <option value="kegiatan">Kegiatan</option>
                                <option value="pengumuman">Pengumuman</option>
                            </select>
                        </div>

                        <!-- News Grid -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <div v-for="newsItem in filteredNews" :key="newsItem.id" 
                                class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                                <div class="relative h-48">
                                    <LazyImage 
                                        :src="newsItem.featured_image ? `/storage/${newsItem.featured_image}` : '/placeholder.svg'" 
                                        :alt="newsItem.title"
                                        imageClass="w-full h-full object-cover"
                                    />
                                    <div class="absolute top-2 right-2">
                                        <span class="px-2 py-1 text-xs font-semibold rounded-full"
                                            :class="getStatusClass(newsItem.status)">
                                            {{ getStatusText(newsItem.status) }}
                                        </span>
                                    </div>
                                </div>
                                <div class="p-4">
                                    <div class="flex items-center text-sm text-gray-500 mb-2">
                                        <span class="mr-2">{{ formatDate(newsItem.publish_date) }}</span>
                                        <span class="px-2 py-1 bg-gray-100 rounded-full text-xs">
                                            {{ getCategoryText(newsItem.category) }}
                                        </span>
                                    </div>
                                    <h2 class="text-xl font-semibold text-gray-900 mb-2 line-clamp-2">
                                        {{ newsItem.title }}
                                    </h2>
                                    <p class="text-gray-600 mb-4 line-clamp-3" v-html="newsItem.content"></p>
                                    <Link :href="route('guest.news.show', newsItem.id)"
                                        class="inline-flex items-center text-indigo-600 hover:text-indigo-800">
                                        Baca Selengkapnya
                                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                                        </svg>
                                    </Link>
                                </div>
                            </div>
                        </div>

                        <!-- Empty State -->
                        <div v-if="filteredNews.length === 0" class="text-center py-12">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                            </svg>
                            <h3 class="mt-2 text-sm font-medium text-gray-900">Tidak ada berita</h3>
                            <p class="mt-1 text-sm text-gray-500">Belum ada berita yang dipublikasikan.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </GuestLayout>
</template>

<script setup>
import { ref, computed } from 'vue';
import GuestLayout from '@/Layouts/GuestLayout.vue';
import { Link } from '@inertiajs/vue3';
import LazyImage from '@/Components/LazyImage.vue';

const props = defineProps({
    news: Array
});

const filters = ref({
    category: ''
});

const filteredNews = computed(() => {
    if (!filters.value.category) return props.news;
    return props.news.filter(item => item.category === filters.value.category);
});

const getStatusClass = (status) => {
    const classes = {
        draft: 'bg-gray-100 text-gray-800',
        published: 'bg-green-100 text-green-800',
        archived: 'bg-yellow-100 text-yellow-800'
    };
    return classes[status] || 'bg-gray-100 text-gray-800';
};

const getStatusText = (status) => {
    const texts = {
        draft: 'Draft',
        published: 'Dipublikasi',
        archived: 'Diarsipkan'
    };
    return texts[status] || status;
};

const getCategoryText = (category) => {
    const texts = {
        umum: 'Umum',
        pemerintahan: 'Pemerintahan',
        kegiatan: 'Kegiatan',
        pengumuman: 'Pengumuman'
    };
    return texts[category] || category;
};

const formatDate = (date) => {
    return new Date(date).toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
};
</script>
