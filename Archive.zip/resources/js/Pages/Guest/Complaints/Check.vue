<template>
    <GuestLayout>

        <Head title="Cek Status Pengaduan" />

        <!-- Hero Section -->
        <div class="bg-gradient-to-r from-green-600 to-green-800 text-white py-16">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center">
                    <h1 class="text-4xl font-bold mb-4">Cek Status Pengaduan</h1>
                    <p class="text-xl text-green-100">
                        Masukkan nomor tiket untuk melihat status pengaduan Anda
                    </p>
                </div>
            </div>
        </div>

        <!-- Check Form Section -->
        <div class="py-16 bg-gray-50">
            <div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="bg-white rounded-lg shadow-lg p-8">
                    <div class="mb-8 text-center">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <svg class="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                        </div>
                        <h2 class="text-2xl font-bold text-gray-900 mb-2">Lacak Pengaduan</h2>
                        <p class="text-gray-600">
                            Masukkan nomor tiket pengaduan untuk melihat status terkini
                        </p>
                    </div>

                    <form @submit.prevent="checkComplaint" class="space-y-6">
                        <div>
                            <label for="complaint_number" class="block text-sm font-medium text-gray-700 mb-2">
                                Nomor Tiket Pengaduan
                            </label>
                            <input id="complaint_number" v-model="form.complaint_number" type="text" required
                                class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-center text-lg font-mono"
                                placeholder="COMP-XXXXXXXX" style="text-transform: uppercase" />
                            <div v-if="errors.complaint_number" class="mt-1 text-sm text-red-600">
                                {{ errors.complaint_number }}
                            </div>
                        </div>

                        <button type="submit" :disabled="processing"
                            class="w-full px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium">
                            <span v-if="processing">Mencari...</span>
                            <span v-else>Cek Status</span>
                        </button>
                    </form>

                    <!-- Error Message -->
                    <div v-if="error" class="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                        <div class="flex">
                            <svg class="w-5 h-5 text-red-400 mt-0.5 mr-3" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd"
                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                                    clip-rule="evenodd" />
                            </svg>
                            <div>
                                <h3 class="text-sm font-medium text-red-800">Pengaduan Tidak Ditemukan</h3>
                                <p class="mt-1 text-sm text-red-700">{{ error }}</p>
                            </div>
                        </div>
                    </div>

                    <!-- Complaint Details -->
                    <div v-if="complaint" class="mt-8 border-t pt-8">
                        <div class="bg-gray-50 rounded-lg p-6">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-lg font-semibold text-gray-900">Detail Pengaduan</h3>
                                <span :class="getStatusClass(complaint.status)"
                                    class="px-3 py-1 rounded-full text-sm font-medium">
                                    {{ getStatusText(complaint.status) }}
                                </span>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                <div>
                                    <p class="text-sm text-gray-600">Nomor Tiket</p>
                                    <p class="font-mono font-medium">{{ complaint.complaint_number }}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Tanggal Pengajuan</p>
                                    <p class="font-medium">{{ formatDate(complaint.created_at) }}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-600">Kategori</p>
                                    <p class="font-medium">{{ getCategoryText(complaint.category) }}</p>
                                </div>
                                <div v-if="complaint.response_date">
                                    <p class="text-sm text-gray-600">Tanggal Respon</p>
                                    <p class="font-medium">{{ formatDate(complaint.response_date) }}</p>
                                </div>
                            </div>

                            <div class="mb-4">
                                <p class="text-sm text-gray-600 mb-2">Judul Pengaduan</p>
                                <p class="font-medium">{{ complaint.title }}</p>
                            </div>

                            <div class="mb-4">
                                <p class="text-sm text-gray-600 mb-2">Deskripsi</p>
                                <p class="text-gray-800">{{ complaint.description }}</p>
                            </div>

                            <div v-if="complaint.response" class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                <p class="text-sm text-blue-600 font-medium mb-2">Tanggapan Petugas</p>
                                <p class="text-blue-800">{{ complaint.response }}</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Help Section -->
                <div class="mt-8 bg-white rounded-lg shadow p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Butuh Bantuan?</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="flex items-start">
                            <svg class="w-5 h-5 text-gray-400 mt-1 mr-3" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                            </svg>
                            <div>
                                <p class="font-medium text-gray-900">Hubungi Kami</p>
                                <p class="text-gray-600">0274-123456</p>
                            </div>
                        </div>
                        <div class="flex items-start">
                            <svg class="w-5 h-5 text-gray-400 mt-1 mr-3" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                            </svg>
                            <div>
                                <p class="font-medium text-gray-900">Email</p>
                                <p class="text-gray-600">pengaduan@desa.go.id</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </GuestLayout>
</template>

<script setup>
import { Head, useForm } from '@inertiajs/vue3'
import { ref } from 'vue'
import GuestLayout from '@/Layouts/GuestLayout.vue'
import { route } from 'laravel-vite-plugin/inertia-helpers';

const form = useForm({
    complaint_number: ''
})

const complaint = ref(null)
const error = ref(null)
const processing = ref(false)

const checkComplaint = async () => {
    processing.value = true
    error.value = null
    complaint.value = null

    try {
        const response = await fetch(route('complaints.check'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            },
            body: JSON.stringify({
                complaint_number: form.complaint_number
            })
        })

        const data = await response.json()

        if (response.ok) {
            complaint.value = data.complaint
        } else {
            error.value = data.message || 'Pengaduan tidak ditemukan'
        }
    } catch (err) {
        error.value = 'Terjadi kesalahan saat mencari pengaduan'
    } finally {
        processing.value = false
    }
}

const getStatusClass = (status) => {
    const classes = {
        pending: 'bg-yellow-100 text-yellow-800',
        in_progress: 'bg-blue-100 text-blue-800',
        resolved: 'bg-green-100 text-green-800',
        rejected: 'bg-red-100 text-red-800'
    }
    return classes[status] || 'bg-gray-100 text-gray-800'
}

const getStatusText = (status) => {
    const texts = {
        pending: 'Menunggu',
        in_progress: 'Diproses',
        resolved: 'Selesai',
        rejected: 'Ditolak'
    }
    return texts[status] || status
}

const getCategoryText = (category) => {
    const texts = {
        infrastructure: 'Infrastruktur',
        security: 'Keamanan',
        environment: 'Lingkungan',
        public_service: 'Pelayanan Publik',
        other: 'Lainnya'
    }
    return texts[category] || category
}

const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    })
}

defineProps({
    errors: Object
})
</script>
