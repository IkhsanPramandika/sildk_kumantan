<?php

namespace App\Http\Controllers\Guest;

use App\Http\Controllers\Controller;
use App\Models\Gallery;
use Inertia\Inertia;

class GalleryController extends Controller
{
    public function index()
    {
        $galleries = Gallery::with('images')
            ->where('is_published', true)
            ->latest()
            ->paginate(9)
            ->through(function ($gallery) {
                return [
                    'id' => $gallery->id,
                    'title' => $gallery->title,
                    'description' => $gallery->description,
                    'image_url' => $gallery->images->first()?->image_url,
                ];
            });

        return Inertia::render('Guest/Galleries/Index', [
            'galleries' => $galleries,
        ]);
    }

    public function show(Gallery $gallery)
    {
        if (!$gallery->is_published) {
            abort(404);
        }

        $relatedGalleries = Gallery::with('images')
            ->where('is_published', true)
            ->where('id', '!=', $gallery->id)
            ->latest()
            ->take(3)
            ->get()
            ->map(function ($gallery) {
                return [
                    'id' => $gallery->id,
                    'title' => $gallery->title,
                    'description' => $gallery->description,
                    'image_url' => $gallery->images->first()?->image_url,
                ];
            });

        return Inertia::render('Guest/Galleries/Show', [
            'gallery' => [
                'id' => $gallery->id,
                'title' => $gallery->title,
                'description' => $gallery->description,
                'images' => $gallery->images->map(function ($image) {
                    return [
                        'id' => $image->id,
                        'image_url' => $image->image_url,
                        'caption' => $image->caption,
                    ];
                }),
            ],
            'relatedGalleries' => $relatedGalleries,
        ]);
    }
}
