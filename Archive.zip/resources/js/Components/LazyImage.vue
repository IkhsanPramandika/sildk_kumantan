<template>
    <div class="relative" :class="containerClass" ref="container">
        <PlaceholderImage v-if="!isLoaded" :class="imageClass" />
        <img
            v-show="isLoaded"
            :src="src"
            :alt="alt"
            :class="imageClass"
            @load="onImageLoad"
            loading="lazy"
        />
    </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';
import PlaceholderImage from './PlaceholderImage.vue';

const props = defineProps({
    src: {
        type: String,
        required: true
    },
    alt: {
        type: String,
        default: ''
    },
    imageClass: {
        type: String,
        default: ''
    },
    containerClass: {
        type: String,
        default: ''
    }
});

const isLoaded = ref(false);
const container = ref(null);
let observer = null;

const onImageLoad = () => {
    isLoaded.value = true;
};

onMounted(() => {
    if (!container.value) return;

    observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target.querySelector('img');
                if (img) {
                    img.src = props.src;
                }
                observer.unobserve(entry.target);
            }
        });
    }, {
        rootMargin: '50px 0px',
        threshold: 0.01
    });

    observer.observe(container.value);
});

onUnmounted(() => {
    if (observer) {
        observer.disconnect();
    }
});
</script> 