<template>
    <div>
        <h1>Products</h1>
        <ul>
            <li v-for="product in products" :key="product.id">
                {{ product.name }} - {{ product.price }}
                <Link :href="route('products.show', product.id)">View</Link>
            </li>
        </ul>
    </div>
</template>

<script>
import { Link } from '@inertiajs/vue3';
import { ref, onMounted } from 'vue';

export default {
    components: {
        Link,
    },
    props: {
        products: {
            type: Array,
            required: true,
        },
    },
};
</script>
