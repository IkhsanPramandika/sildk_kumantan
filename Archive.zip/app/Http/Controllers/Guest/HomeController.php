<?php

namespace App\Http\Controllers\Guest;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Gallery;
use App\Models\News;
use App\Models\Product;
use App\Models\Resident;
use App\Models\VillageProfile;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        // Define configurable limits (can be overridden by query parameters or config)
        $newsLimit = $request->query('news_limit', config('app.home.news_limit', 3));
        $eventsLimit = $request->query('events_limit', config('app.home.events_limit', 3));
        $galleriesLimit = $request->query('galleries_limit', config('app.home.galleries_limit', 3));
        $productsLimit = $request->query('products_limit', config('app.home.products_limit', 4));

        // Define cache duration (in minutes)
        $cacheTtl = config('app.home.cache_ttl', 30);

        // Cache key for storing home page data
        $cacheKey = 'home_data_' . md5(serialize($request->query()));

        try {
            // Attempt to retrieve cached data
            $data = Cache::remember($cacheKey, $cacheTtl, function () use ($newsLimit, $eventsLimit, $galleriesLimit, $productsLimit) {
                // Get village profile
                $villageProfile = VillageProfile::first();

                // Get statistics
                $stats = [
                    'total_residents' => Resident::count(),
                    'total_male' => Resident::where('gender', 'Laki-laki')->count(),
                    'total_female' => Resident::where('gender', 'Perempuan')->count(),
                    'total_news' => News::where('status', 'published')->count(),
                ];

                // Fetch latest news
                $latestNews = News::with('images')
                    ->where('status', 'published')
                    ->orderBy('publish_date', 'desc')
                    ->take($newsLimit)
                    ->get()
                    ->map(function ($news) {
                        return [
                            'id' => $news->id,
                            'title' => $news->title,
                            'content' => $news->content,
                            'description' => $news->content ? substr(strip_tags($news->content), 0, 150) . '...' : '',
                            'category' => $news->category,
                            'image_url' => $news->images->first()?->image_url,
                            'publish_date' => Carbon::parse($news->publish_date)->locale('id')->isoFormat('D MMMM YYYY'),
                        ];
                    });

                // Fetch upcoming events
                $upcomingEvents = Event::with('images')
                    ->where('status', 'published')
                    ->where('start_date', '>=', now())
                    ->orderBy('start_date', 'asc')
                    ->take($eventsLimit)
                    ->get()
                    ->map(function ($event) {
                        return [
                            'id' => $event->id,
                            'title' => $event->title,
                            'description' => $event->description,
                            'category' => $event->category,
                            'image_url' => $event->images->first()?->image_url,
                            'start_date' => Carbon::parse($event->start_date)->locale('id')->isoFormat('D MMMM YYYY'),
                            'end_date' => Carbon::parse($event->end_date)->locale('id')->isoFormat('D MMMM YYYY'),
                            'location' => $event->location,
                        ];
                    });

                // Fetch latest galleries
                $latestGalleries = Gallery::with('images')
                    ->where('is_published', true)
                    ->orderBy('created_at', 'desc')
                    ->take($galleriesLimit)
                    ->get()
                    ->map(function ($gallery) {
                        return [
                            'id' => $gallery->id,
                            'title' => $gallery->title,
                            'description' => $gallery->description,
                            'image_url' => $gallery->images->first()?->image_url,
                            'images_count' => $gallery->images->count(),
                        ];
                    });

                // Fetch featured products
                $featuredProducts = Product::with(['seller', 'images'])
                    ->where('status', 'published')
                    ->orderBy('created_at', 'desc')
                    ->take($productsLimit)
                    ->get()
                    ->map(function ($product) {
                        return [
                            'id' => $product->id,
                            'name' => $product->name,
                            'description' => $product->description,
                            'price' => $product->price,
                            'category' => $product->category,
                            'image_url' => $product->images->first()?->image_url,
                            'seller' => $product->seller ? [
                                'id' => $product->seller->id,
                                'name' => $product->seller->name,
                            ] : null,
                        ];
                    });

                return [
                    'villageProfile' => $villageProfile,
                    'stats' => $stats,
                    'latestNews' => $latestNews,
                    'upcomingEvents' => $upcomingEvents,
                    'latestGalleries' => $latestGalleries,
                    'featuredProducts' => $featuredProducts,
                ];
            });

            return Inertia::render('Guest/Home', $data);
        } catch (\Exception $e) {
            // Log the error and return a fallback response
            Log::error('Error fetching home page data: ' . $e->getMessage());

            // Return fallback data
            return Inertia::render('Guest/Home', [
                'villageProfile' => VillageProfile::first() ?? [],
                'stats' => [
                    'total_residents' => 0,
                    'total_male' => 0,
                    'total_female' => 0,
                    'total_news' => 0,
                ],
                'latestNews' => [],
                'upcomingEvents' => [],
                'latestGalleries' => [],
                'featuredProducts' => [],
                'error' => 'Unable to load data at this time. Please try again later.',
            ]);
        }
    }
}
