<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('residents', function (Blueprint $table) {
            $table->id();
            $table->string('nik', 16)->unique()->nullable();
            $table->string('family_card_number', 16)->nullable();
            $table->string('full_name')->nullable();
            $table->text('address')->nullable();
            $table->string('rt', 3)->nullable();
            $table->string('rw', 3)->nullable();
            $table->string('hamlet')->nullable();
            $table->string('birth_place')->nullable();
            $table->date('birth_date')->nullable();
            $table->enum('gender', ['male', 'female'])->nullable();
            $table->enum('religion', ['islam', 'christian', 'catholic', 'hindu', 'buddhist', 'confucian', 'other'])->nullable();
            $table->enum('marital_status', ['single', 'married', 'divorced', 'widowed'])->nullable();
            $table->string('occupation')->nullable();
            $table->enum('last_education', ['none', 'elementary', 'junior_high', 'senior_high', 'd1', 'd2', 'd3', 's1', 's2', 's3'])->nullable();
            $table->enum('blood_type', ['A', 'B', 'AB', 'O', 'Unknown'])->nullable();
            $table->enum('citizenship', ['wni', 'wna'])->default('wni')->nullable();
            $table->enum('life_status', ['alive', 'deceased'])->default('alive')->nullable();
            $table->string('mother_name')->nullable();
            $table->string('father_name')->nullable();
            $table->string('family_relationship_status', 50)->nullable();
            $table->string('disability_type', 50)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('residents');
    }
};
