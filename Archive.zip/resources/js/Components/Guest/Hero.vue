<template>
    <div class="relative h-[500px] overflow-hidden">
        <LazyImage 
            :src="imageUrl || '/placeholder.svg?height=800&width=1600'" 
            alt="Hero background"
            imageClass="w-full h-full object-cover"
        />
        <div class="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div class="text-center text-white">
                <h1 class="text-4xl md:text-6xl font-bold mb-4">{{ title }}</h1>
                <p class="text-xl md:text-2xl">{{ subtitle }}</p>
            </div>
        </div>
    </div>
</template>

<script setup>
import LazyImage from '@/Components/LazyImage.vue';

defineProps({
    title: {
        type: String,
        required: true
    },
    subtitle: {
        type: String,
        required: true
    },
    imageUrl: {
        type: String,
        default: null
    }
});
</script>
