<template>
    <div class="relative w-full h-64 md:h-96 overflow-hidden">
        <div class="absolute inset-0 flex transition-transform duration-500" :style="{ transform: `translateX(-${currentIndex * 100}%)` }">
            <LazyImage 
                v-for="(image, index) in images" 
                :key="index" 
                :src="image" 
                :alt="`Slider Image ${index + 1}`"
                imageClass="w-full h-full object-cover flex-shrink-0"
            />
        </div>

        <div class="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
            <button v-for="(image, index) in images" :key="index" @click="goTo(index)"
                class="w-3 h-3 rounded-full"
                :class="{ 'bg-white': currentIndex === index, 'bg-gray-500': currentIndex !== index }"></button>
        </div>

        <button @click="prev" class="absolute top-1/2 transform -translate-y-1/2 left-4 bg-black bg-opacity-50 text-white p-2 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </button>

        <button @click="next" class="absolute top-1/2 transform -translate-y-1/2 right-4 bg-black bg-opacity-50 text-white p-2 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
            </svg>
        </button>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import LazyImage from '@/Components/LazyImage.vue';

const images = ref([
    '/images/slider/slider1.jpg',
    '/images/slider/slider2.jpg',
    '/images/slider/slider3.jpg',
]);

const currentIndex = ref(0);

const next = () => {
    currentIndex.value = (currentIndex.value + 1) % images.value.length;
};

const prev = () => {
    currentIndex.value = (currentIndex.value - 1 + images.value.length) % images.value.length;
};

const goTo = (index) => {
    currentIndex.value = index;
};

onMounted(() => {
    const interval = setInterval(next, 5000);

    // Clear interval on component unmount
    onBeforeUnmount(() => clearInterval(interval));
});
</script>
