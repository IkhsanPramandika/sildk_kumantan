<template>
    <div v-if="isOpen" class="fixed top-0 left-0 w-full h-full bg-black bg-opacity-80 z-50 flex items-center justify-center">
        <button @click="closeLightbox" class="absolute top-4 right-4 text-white text-4xl focus:outline-none">&times;</button>
        <LazyImage 
            :src="imageUrl" 
            alt="Lightbox Image" 
            imageClass="max-w-full max-h-full"
        />
    </div>
</template>

<script setup>
import { ref } from 'vue';
import LazyImage from '@/Components/LazyImage.vue';

const isOpen = ref(false);
const imageUrl = ref('');

const openLightbox = (url) => {
    imageUrl.value = url;
    isOpen.value = true;
};

const closeLightbox = () => {
    isOpen.value = false;
};

defineExpose({
    openLightbox
});
</script>

<style scoped>

</style>
