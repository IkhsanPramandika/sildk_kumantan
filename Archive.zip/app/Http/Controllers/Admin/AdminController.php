<?php

namespace App\Http\Controllers\Admin;

use App\Models\News;
use Inertia\Inertia;
use App\Models\Event;
use App\Models\Product;
use App\Models\Business;
use App\Models\Resident;
use App\Models\Complaint;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AdminController extends Controller
{
    public function dashboard()
    {
        $stats = [
            'residents' => Resident::count(),
            'products' => Product::count(),
            'activeEvents' => Event::whereIn('status', ['upcoming', 'ongoing'])->count(),
            'recentNews' => News::where('status', 'published')->count(),
            'newComplaints' => Complaint::where('status', 'pending')->count(),
        ];

        $recentEvents = Event::whereIn('status', ['upcoming', 'ongoing'])
            ->latest()
            ->take(5)
            ->get();

        $recentNews = News::where('status', 'published')
            ->latest()
            ->take(5)
            ->get();

        $recentComplaints = Complaint::with('resident')
            ->latest()
            ->take(5)
            ->get();

        return Inertia::render('Admin/Dashboard', [
            'stats' => $stats,
            'recentEvents' => $recentEvents,
            'recentNews' => $recentNews,
            'recentComplaints' => $recentComplaints,
        ]);
    }
}
