<template>
    <div>
        <h1>Gallery Details</h1>
        <p>Gallery ID: {{ gallery.id }}</p>
        <p>Gallery Name: {{ gallery.name }}</p>
        <p>Gallery Description: {{ gallery.description }}</p>

        <div v-if="gallery.images && gallery.images.length > 0">
            <h2>Images:</h2>
            <div style="display: flex; flex-wrap: wrap;">
                <LazyImage 
                    v-for="image in gallery.images" 
                    :key="image.id" 
                    :src="image.url" 
                    alt="Gallery Image" 
                    imageClass="w-48 h-48 object-cover m-2.5"
                />
            </div>
        </div>
        <div v-else>
            <p>No images available for this gallery.</p>
        </div>

        <Link :href="route('guest.galleries.index')">Back to Galleries</Link>
    </div>
</template>

<script setup>
import { defineProps } from 'vue';
import { Link } from '@inertiajs/vue3';
import LazyImage from '@/Components/LazyImage.vue';

const props = defineProps({
    gallery: {
        type: Object,
        required: true
    }
});

</script>
