<template>
    <GuestLayout>
        <!-- Hero Section with Village Profile Info -->
        <Hero title="Selamat Datang di Desa Digital"
              subtitle="Mewujudkan desa yang maju, mandiri, dan sejahtera melalui pemanfaatan teknologi digital."
              image-url="https://via.placeholder.com/1200x400?text=Village+Image">
            <Link :href="route('about')"
                  class="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-700 hover:bg-blue-800">
                Tentang Kami
            </Link>
            <Link :href="route('contact')"
                  class="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-white hover:bg-gray-50">
                Hubungi Kami
            </Link>
        </Hero>

        <!-- Village Profile Section -->
        <section class="py-16 bg-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                <SectionHeading title="Profil Desa" subtitle="Mengenal lebih dekat desa kami" />

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div>
                        <div class="prose prose-lg max-w-none">
                            <h3 class="text-2xl font-bold text-gray-900 mb-4">Visi</h3>
                            <p class="text-gray-700">Mewujudkan desa yang maju, mandiri, dan sejahtera melalui pemanfaatan teknologi digital.</p>

                            <h3 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Misi</h3>
                            <div class="text-gray-700">
                                <ul class="list-disc pl-5 space-y-2">
                                    <li>Mengembangkan infrastruktur digital desa</li>
                                    <li>Meningkatkan kualitas layanan publik berbasis teknologi</li>
                                    <li>Memberdayakan masyarakat melalui literasi digital</li>
                                    <li>Mendorong pertumbuhan ekonomi digital desa</li>
                                </ul>
                            </div>

                            <h3 class="text-2xl font-bold text-gray-900 mt-8 mb-4">Sejarah Desa</h3>
                            <p class="text-gray-700">{{ villageProfile.village_history || 'Desa ini berdiri sejak lama, berkembang menjadi pusat inovasi digital untuk kesejahteraan masyarakat.' }}</p>

                            <div v-if="villageProfile.village_history_image" class="mt-6">
                                <img :src="villageProfile.village_history_image" alt="Sejarah Desa" class="w-full h-auto rounded-lg shadow-sm">
                            </div>
                            <div v-else class="mt-6">
                                <img src="https://via.placeholder.com/600x400?text=Sejarah+Desa" alt="Sejarah Desa" class="w-full h-auto rounded-lg shadow-sm">
                            </div>

                            <div v-if="villageProfile.organization_structure_image" class="mt-8 p-4 bg-gray-50 rounded-lg border border-gray-200">
                                <h4 class="text-lg font-semibold text-gray-900 mb-2">Struktur Organisasi</h4>
                                <img :src="villageProfile.organization_structure_image" alt="Struktur Organisasi" class="w-full h-auto rounded-lg">
                            </div>
                            <div v-else class="mt-8 p-4 bg-gray-50 rounded-lg border border-gray-200adow-sm">
                                <h4 class="text-lg font-semibold text-gray-900 mb-2">Struktur Organisasi</h4>
                                <img src="https://via.placeholder.com/600x400?text=Struktur+Organisasi" alt="Struktur Organisasi" class="w-full h-auto rounded-lg">
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="bg-gray-50 p-6 rounded-lg shadow-sm border border-gray-200">
                            <h3 class="text-xl font-bold text-gray-900 mb-4">Alamat & Kontak</h3>

                            <div class="space-y-3">
                                <div class="flex items-start">
                                    <MapPinIcon class="w-5 h-5 text-blue-600 mt-1 mr-3 flex-shrink-0" />
                                    <div class="p">
                                        <div>
                                            <p class="text-gray-700">Jl. Desa Digital No. 1, RT 07/RW 05</p>
                                            <p class="text-gray-600">Kecamatan Digital, Kota Digital, Provinsi Digital, 53245</p>
                                        </div>
                                    </div>

                                    <div class="flex items-center">
                                        <PhoneIcon class="w-5 h-5 text-blue-600 mr-3 flex-shrink-0" />
                                        <p class="text-gray-700">(021) 1234-5678</p>
                                    </div>

                                    <div class="flex items-center">
                                        <EnvelopeIcon class="w-5 h-5 text-blue-600 mr-3 flex-shrink-0" />
                                        <p class="text-gray-700">info@desadigital.id</p>
                                    </div>

                                    <div class="flex items-center">
                                        <GlobeAltIcon class="w-5 h-5 text-blue-600 mr-3 flex-shrink-0" />
                                        <p class="text-blue-600">
                                            <a href="https://desadigital.org" target="_blank" class="text-blue-600 hover:underline">desadigital.org</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    </div>
            </section>

            <!-- Stats Section -->
            <section class="py-12 bg-gray-50">
                <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                        <StatCard :icon="UsersIcon" :value="stats.total_residents || 0" label="Total Penduduk" />
                        <StatCard :icon="UserIcon" :value="stats.total_male || 0" label="Laki-laki" />
                        <StatCard :icon="UserIcon" :value="stats.total_female || 0" label="Perempuan"/>
                         <StatCard :icon="NewspaperIcon" :value="stats.total_news || 0" label="Berita" />
                    </div>
                </div>
            </section>

            <!-- Latest News Section -->
<section v-if="latestNews && latestNews.length > 0" class="py-16 bg-white">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading title="Berita Terbaru"
            subtitle="Informasi terkini seputar kegiatan dan perkembangan desa" />

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <NewsCard v-for="news in latestNews" :key="news.id" :id="news.id" :title="news.title"
                :description="news.description"
                :image-url="news.image_url || '/placeholder.svg?height=300&w=400&text=No+Image'"
                :category="getCategoryText(news.category)" :date="news.publish_date" />
        </div>

        <div class="text-center mt-10">
            <Link :href="route('news.index')"
                class="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                Lihat Semua Berita
                <ArrowRightIcon class="w-5 h-5 ml-2" />
            </Link>
        </div>
    </div>
</section>

            <!-- Upcoming Events Section -->
<section v-if="upcomingEvents && upcomingEvents.length > 0" class="py-16 bg-gray-50">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeading title="Agenda Mendatang"
            subtitle="Jadwal kegiatan dan acara yang akan diselenggarakan di desa" />

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <EventCard v-for="event in upcomingEvents" :key="event.id" :id="event.id" :title="event.title"
                :description="event.description"
                :image-url="event.image_url || '/placeholder.svg?height=300&w=400&text=No+Image'"
                :category="getCategoryText(event.category)"
                :start_date="event.start_date" :end-date="event.end_date" :location="event.location" />
        </div>

        <div class="text-center mt-10">
            <Link :href="route('events.index')"
                class="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                Lihat Semua Agenda
                <ArrowRightIcon class="w-5 h-5 ml-2" />
            </Link>
        </div>
    </div>
</section>

                <!-- Gallery Section -->
                <section v-if="latestGalleries && latestGalleries.length > 0" class="py-16 bg-white">
                    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                        <SectionHeading title="Galeri Desa" subtitle="Dokumentasi kegiatan dan momen penting di desa" />

                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                            <GalleryCard v-for="gallery in latestGalleries" :key="gallery.id" :id="gallery.id"
                                :title="gallery.title" :description="gallery.description"
                                :image-url="gallery.image_url || '/placeholder.svg?height=300&w=400&text=No+Image'"
                                :images-count="gallery.images_count || 0" />
                        </div>

                        <div class="text-center mt-10">
                            <Link :href="route('galleries.index')"
                                class="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                                Lihat Semua Galeri
                                <ArrowRightIcon class="w-5 h-5 ml-2" />
                            </Link>
                        </div>
                    </div>
                </section>

                <!-- Featured Products Section -->
                <section v-if="featuredProducts && featuredProducts.length > 0" class="py-16 bg-gray-50">
                    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                        <SectionHeading title="Produk UMKM" subtitle="Produk unggulan dari UMKM lokal desa" />

                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <ProductCard v-for="product in featuredProducts" :key="product.id" :id="product.id"
                                :name="product.name" :description="product.description"
                                :image-url="product.image_url || '/placeholder.svg?height=300&w=400&text=No+Image'"
                                :category="getCategoryText(product.category, 'product')" :price="product.price"
                                :seller="product.seller ? product.seller.name : 'Unknown'" />
                        </div>

                        <div class="text-center mt-10">
                            <Link :href="route('products.index')"
                                class="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                                Lihat Semua Produk
                                <ArrowRightIcon class="w-5 h-5 ml-2" />
                            </Link>
                        </div>
                    </div>
                </section>

                <!-- Empty State when no content -->
                <section v-if="!hasAnyContent" class="py-16 bg-white">
                    <div class="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
                        <div class="max-w-md mx-auto">
                            <NewspaperIcon class="mx-auto h-12 w-12 text-gray-400" />
                            <h3 class="mt-2 text-sm font-medium text-gray-900">Belum ada konten</h3>
                            <p class="mt-1 text-sm text-gray-500">
                                Konten akan ditampilkan setelah admin menambahkan berita, acara, atau galeri.
                            </p>
                        </div>
                    </div>
                </section>

                <!-- CTA Section -->
                <section class="py-16 bg-blue-600">
                    <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                        <div class="text-center">
                            <h2 class="text-3xl font-bold text-white mb-4">Ada keluhan atau saran?</h2>
                            <p class="text-xl text-white opacity-90 mb-8 max-w-3xl mx-auto">
                                Sampaikan keluhan atau saran Anda untuk membantu kami meningkatkan pelayanan dan fasilitas desa.
                            </p>
                            <Link :href="route('complaints.create')"
                                class="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-white hover:bg-gray-50">
                                Buat Pengaduan
                                <ArrowRightIcon class="w-5 h-5 ml-2" />
                            </Link>
                        </div>
                    </div>
                </section>
            </GuestLayout>
        </template>

        <script setup>
        import { ref, computed } from 'vue'
        import { Link } from '@inertiajs/vue3'
        import GuestLayout from '@/Layouts/GuestLayout.vue'
        import Hero from '@/Components/Guest/Hero.vue'
        import SectionHeading from '@/Components/Guest/SectionHeading.vue'
        import StatCard from '@/Components/Guest/StatCard.vue'
        import NewsCard from '@/Components/Guest/NewsCard.vue'
        import EventCard from '@/Components/Guest/EventCard.vue'
        import GalleryCard from '@/Components/Guest/GalleryCard.vue'
        import ProductCard from '@/Components/Guest/ProductCard.vue'
        import {
            ArrowRightIcon,
            UsersIcon,
            UserIcon,
            NewspaperIcon,
            MapPinIcon,
            PhoneIcon,
            EnvelopeIcon,
            GlobeAltIcon
        } from '@heroicons/vue/24/outline'

        const props = defineProps({
            stats: {
                type: Object,
                default: () => ({
                    total_residents: 0,
                    total_male: 0,
                    total_female: 0,
                    total_news: 0
                })
            },
            latestNews: {
                type: Array,
                default: () => []
            },
            upcomingEvents: {
                type: Array,
                default: () => []
            },
            latestGalleries: {
                type: Array,
                default: () => []
            },
            featuredProducts: {
                type: Array,
                default: () => []
            },
            villageProfile: {
                type: Object,
                default: () => ({
                    organization_structure_image: '',
                    village_history: '',
                    village_history_image: ''
                })
            }
        })

        // Computed property to check if there's any content to display
        const hasAnyContent = computed(() => {
            return (props.latestNews && props.latestNews.length > 0) ||
                (props.upcomingEvents && props.upcomingEvents.length > 0) ||
                (props.latestGalleries && props.latestGalleries.length > 0) ||
                (props.featuredProducts && props.featuredProducts.length > 0)
        })

        const getCategoryText = (category, type = 'default') => {
            if (type === 'product') {
                const productCategories = {
                    food: 'Makanan',
                    craft: 'Kerajinan',
                    agriculture: 'Pertanian',
                    fashion: 'Fashion',
                    other: 'Lainnya'
                }
                return productCategories[category] || category || 'Umum'
            }

            const categories = {
                umum: 'Umum',
                pemerintahan: 'Pemerintahan',
                kegiatan: 'Kegiatan',
                pengumuman: 'Pengumuman'
            }
            return categories[category] || category || 'Umum'
        }
        </script>
