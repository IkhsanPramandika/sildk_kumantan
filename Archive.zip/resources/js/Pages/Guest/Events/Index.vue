<template>
    <GuestLayout title="Event">
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h1 class="text-2xl font-semibold text-gray-900 mb-6">Event Mendatang</h1>
                        
                        <!-- Filters -->
                        <div class="mb-6 flex flex-wrap gap-4">
                            <select v-model="filters.category" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                <option value="">Semua Kategori</option>
                                <option value="umum">Umum</option>
                                <option value="pemerintahan">Pemerintahan</option>
                                <option value="kegiatan">Kegiatan</option>
                                <option value="pengumuman">Pengumuman</option>
                            </select>
                            <select v-model="filters.status" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                <option value="">Semua Status</option>
                                <option value="upcoming">Akan Datang</option>
                                <option value="ongoing">Berlangsung</option>
                                <option value="completed">Selesai</option>
                            </select>
                        </div>

                        <!-- Events Grid -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <div v-for="event in filteredEvents" :key="event.id" 
                                class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                                <div class="relative h-48">
                                    <LazyImage 
                                        :src="event.featured_image ? `/storage/${event.featured_image}` : '/placeholder.svg'" 
                                        :alt="event.title"
                                        imageClass="w-full h-full object-cover"
                                    />
                                    <div class="absolute top-2 right-2">
                                        <span class="px-2 py-1 text-xs font-semibold rounded-full"
                                            :class="getStatusClass(event.status)">
                                            {{ getStatusText(event.status) }}
                                        </span>
                                    </div>
                                </div>
                                <div class="p-4">
                                    <div class="flex items-center text-sm text-gray-500 mb-2">
                                        <span class="mr-2">{{ formatDate(event.start_date) }}</span>
                                        <span class="px-2 py-1 bg-gray-100 rounded-full text-xs">
                                            {{ getCategoryText(event.category) }}
                                        </span>
                                    </div>
                                    <h2 class="text-xl font-semibold text-gray-900 mb-2 line-clamp-2">
                                        {{ event.title }}
                                    </h2>
                                    <p class="text-gray-600 mb-2 line-clamp-2" v-html="event.description"></p>
                                    <div class="flex items-center text-sm text-gray-500 mb-4">
                                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                                d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                        </svg>
                                        {{ event.location }}
                                    </div>
                                    <Link :href="route('guest.events.show', event.id)"
                                        class="inline-flex items-center text-indigo-600 hover:text-indigo-800">
                                        Lihat Detail
                                        <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                                        </svg>
                                    </Link>
                                </div>
                            </div>
                        </div>

                        <!-- Empty State -->
                        <div v-if="filteredEvents.length === 0" class="text-center py-12">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            <h3 class="mt-2 text-sm font-medium text-gray-900">Tidak ada event</h3>
                            <p class="mt-1 text-sm text-gray-500">Belum ada event yang dijadwalkan.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </GuestLayout>
</template>

<script setup>
import { ref, computed } from 'vue';
import GuestLayout from '@/Layouts/GuestLayout.vue';
import { Link } from '@inertiajs/vue3';
import LazyImage from '@/Components/LazyImage.vue';

const props = defineProps({
    events: Array
});

const filters = ref({
    category: '',
    status: ''
});

const filteredEvents = computed(() => {
    return props.events.filter(event => {
        if (filters.value.category && event.category !== filters.value.category) return false;
        if (filters.value.status && event.status !== filters.value.status) return false;
        return true;
    });
});

const getStatusClass = (status) => {
    const classes = {
        upcoming: 'bg-blue-100 text-blue-800',
        ongoing: 'bg-green-100 text-green-800',
        completed: 'bg-gray-100 text-gray-800',
        cancelled: 'bg-red-100 text-red-800'
    };
    return classes[status] || 'bg-gray-100 text-gray-800';
};

const getStatusText = (status) => {
    const texts = {
        upcoming: 'Akan Datang',
        ongoing: 'Berlangsung',
        completed: 'Selesai',
        cancelled: 'Dibatalkan'
    };
    return texts[status] || status;
};

const getCategoryText = (category) => {
    const texts = {
        umum: 'Umum',
        pemerintahan: 'Pemerintahan',
        kegiatan: 'Kegiatan',
        pengumuman: 'Pengumuman'
    };
    return texts[category] || category;
};

const formatDate = (date) => {
    return new Date(date).toLocaleDateString('id-ID', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
};
</script>
