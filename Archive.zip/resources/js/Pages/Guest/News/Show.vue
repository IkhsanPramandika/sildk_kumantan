<template>
    <div>
        <h1>{{ news.title }}</h1>
        <p>{{ news.content }}</p>
        <p>Published at: {{ news.published_at }}</p>
        <router-link :to="route('news.index')">Back to News</router-link>
    </div>
</template>

<script>
export default {
    props: {
        news: {
            type: Object,
            required: true
        }
    }
}
</script>
