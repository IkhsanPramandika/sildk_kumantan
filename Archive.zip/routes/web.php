<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CKEditorController;
use App\Http\Controllers\Admin\NewsController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\EventController;
use App\Http\Controllers\Admin\GalleryController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\ResidentController;
use App\Http\Controllers\Admin\ComplaintController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrganizationController;
use App\Http\Controllers\Admin\VillageHistoryController;
use App\Http\Controllers\Admin\VillageProfileController;
use App\Http\Controllers\Admin\VillagePotentialController;

Route::get('/', function () {
    return view('welcome');
});
Route::get('login', [AuthController::class, 'showLogin'])->name('login');
Route::post('login', [AuthController::class, 'login'])->name('authenticate');

Route::post('ckeditor/upload', [CKEditorController::class, 'upload'])->name('ckeditor.upload');

Route::middleware(['auth', 'verified'])->group(function () {

    Route::prefix('admin')->name('admin.')->group(function () {
        // Dashboard
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');

        // Kependudukan
        Route::resource('residents', ResidentController::class);

        // Potensi Desa
        Route::resource('village-potentials', VillagePotentialController::class);
        Route::resource('products', ProductController::class);

        // Kelembagaan Desa
        Route::get('/village-profile', [VillageProfileController::class, 'edit'])->name('village-profile.edit');
        Route::post('/village-profile', [VillageProfileController::class, 'update'])->name('village-profile.update');
        Route::get('/village-history', [VillageHistoryController::class, 'edit'])->name('village-history.edit');
        Route::post('/village-history', [VillageHistoryController::class, 'update'])->name('village-history.update');
        Route::get('/organizations/{type}', [OrganizationController::class, 'edit'])->name('organizations.edit');
        Route::post('/organizations/{type}', [OrganizationController::class, 'update'])->name('organizations.update');

        // Informasi Publik
        Route::resource('news', NewsController::class);
        Route::resource('events', EventController::class);

        // Gallery Desa
        Route::resource('galleries', GalleryController::class);

        // Pengaduan
        Route::resource('complaints', ComplaintController::class);

        // Profil Desa
        Route::get('/village-profile', [VillageProfileController::class, 'edit'])->name('village-profile.edit');
        Route::post('/village-profile', [VillageProfileController::class, 'update'])->name('village-profile.update');

        // Profile
        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });

    Route::post('logout', [AuthController::class, 'logout'])->name('logout');
});


// Auth Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
});

// Guest Routes
Route::get('/', [App\Http\Controllers\Guest\HomeController::class, 'index'])->name('home');

// News Routes
Route::get('/news', [App\Http\Controllers\Guest\NewsController::class, 'index'])->name('news.index');
Route::get('/news/{news}', [App\Http\Controllers\Guest\NewsController::class, 'show'])->name('news.show');

// Event Routes
Route::get('/events', [App\Http\Controllers\Guest\EventController::class, 'index'])->name('events.index');
Route::get('/events/{event}', [App\Http\Controllers\Guest\EventController::class, 'show'])->name('events.show');

// Gallery Routes
Route::get('/galleries', [App\Http\Controllers\Guest\GalleryController::class, 'index'])->name('galleries.index');
Route::get('/galleries/{gallery}', [App\Http\Controllers\Guest\GalleryController::class, 'show'])->name('galleries.show');

// Product Routes
Route::get('/products', [App\Http\Controllers\Guest\ProductController::class, 'index'])->name('products.index');
Route::get('/products/{product}', [App\Http\Controllers\Guest\ProductController::class, 'show'])->name('products.show');

// Complaint Routes
Route::get('/complaints/create', [App\Http\Controllers\Guest\ComplaintController::class, 'create'])->name('complaints.create');
Route::post('/complaints', [App\Http\Controllers\Guest\ComplaintController::class, 'store'])->name('complaints.store');
Route::get('/complaints/{complaint}', [App\Http\Controllers\Guest\ComplaintController::class, 'show'])->name('complaints.show');
