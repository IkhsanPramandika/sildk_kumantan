<?php

namespace App\Http\Controllers\Guest;

use App\Http\Controllers\Controller;
use App\Models\Complaint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Inertia\Inertia;

class ComplaintController extends Controller
{
    public function create()
    {
        return Inertia::render('Guest/Complaints/Create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'category' => 'required|string|in:infrastructure,security,environment,other',
            'description' => 'required|string',
        ]);

        $complaint = Complaint::create([
            'complaint_number' => 'COMP-' . Str::random(8),
            'resident_id' => Auth::id(),
            'title' => $validated['title'],
            'category' => $validated['category'],
            'description' => $validated['description'],
            'status' => 'pending',
        ]);

        return redirect()->route('guest.complaints.show', $complaint)
            ->with('success', 'Pengaduan berhasil dibuat.');
    }

    public function show(Complaint $complaint)
    {
        if ($complaint->resident_id !== Auth::id()) {
            abort(403);
        }

        return Inertia::render('Guest/Complaints/Show', [
            'complaint' => [
                'id' => $complaint->id,
                'complaint_number' => $complaint->complaint_number,
                'title' => $complaint->title,
                'category' => $complaint->category,
                'description' => $complaint->description,
                'status' => $complaint->status,
                'response' => $complaint->response,
                'response_date' => $complaint->response_date,
                'created_at' => $complaint->created_at,
            ],
        ]);
    }
}
