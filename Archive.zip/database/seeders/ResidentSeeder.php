<?php

namespace Database\Seeders;

use App\Models\Resident;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class ResidentSeeder extends Seeder
{
    public function run(): void
    {
        $faker = Faker::create('id_ID');

        // Create 50 sample residents
        for ($i = 0; $i < 50; $i++) {
            $gender = $faker->randomElement(['male', 'female']);
            $birthDate = $faker->dateTimeBetween('-70 years', '-17 years');

            Resident::create([
                'nik' => $faker->unique()->numerify('################'),
                'family_card_number' => $faker->numerify('################'),
                'full_name' => $faker->name($gender),
                'address' => $faker->address(),
                'rt' => $faker->numberBetween(1, 10),
                'rw' => $faker->numberBetween(1, 5),
                'hamlet' => 'Dusun ' . $faker->randomElement(['A', 'B', 'C', 'D']),
                'birth_place' => $faker->city(),
                'birth_date' => $birthDate,
                'gender' => $gender,
                'religion' => $faker->randomElement(['islam', 'christian', 'catholic', 'hindu', 'buddhist', 'confucian', 'other']),
                'marital_status' => $faker->randomElement(['single', 'married', 'divorced', 'widowed']),
                'occupation' => $faker->jobTitle(),
                'last_education' => $faker->randomElement(['none', 'elementary', 'junior_high', 'senior_high', 'd1', 'd2', 'd3', 's1', 's2', 's3']),
                'blood_type' => $faker->randomElement(['A', 'B', 'AB', 'O', 'Unknown']),
                'citizenship' => 'wni',
                'life_status' => 'alive',
                'mother_name' => $faker->name('female'),
                'father_name' => $faker->name('male'),
                'family_relationship_status' => $faker->randomElement(['kepala_keluarga', 'istri', 'anak', 'orang_tua']),
                'disability_type' => $faker->optional(0.1)->randomElement(['tuna_netra', 'tuna_rungu', 'tuna_daksa', 'tuna_grahita', 'tuna_laras']),
            ]);
        }
    }
}
